import time

import pytest

from helpers import check_invariants, make_prose, pages
from omniparse.chunking import chunk_pages
from omniparse.models import Page, ParseResult


def test_empty_and_blank_pages():
    assert chunk_pages([], max_chars=100) == []
    assert chunk_pages(pages("", "   \n\n "), max_chars=100) == []


def test_small_document_is_one_chunk():
    (c,) = chunk_pages(pages("Hello world."), source="a.pdf", max_chars=100)
    assert (c.index, c.total_chunks, c.prev_id, c.next_id) == (0, 1, None, None)
    assert c.text == "Hello world." and c.overlap_chars == 0


def test_invariants_on_long_prose_with_overlap():
    pgs = pages(make_prose(80), make_prose(60), make_prose(40))
    chunks = chunk_pages(pgs, max_chars=400, overlap_chars=80)
    assert len(chunks) > 10
    check_invariants(pgs, chunks, 400)
    # splits land on sentence boundaries, not mid-word
    for c in chunks:
        assert c.text.rstrip().endswith("."), c.text[-30:]
    # overlap really repeats the tail of the previous chunk, within budget
    for prev, c in zip(chunks, chunks[1:]):
        if c.overlap_chars:
            assert c.overlap_chars <= 80
            assert prev.text.endswith(c.text[:c.overlap_chars].rstrip())


def test_no_overlap_means_disjoint_chunks():
    pgs = pages(make_prose(50))
    chunks = chunk_pages(pgs, max_chars=300, overlap_chars=0)
    check_invariants(pgs, chunks, 300)
    assert all(c.overlap_chars == 0 for c in chunks)
    assert all(a.end_char <= b.start_char for a, b in zip(chunks, chunks[1:]))


def test_chunks_span_pages_and_record_page_range():
    pgs = pages("First page paragraph.", "Second page paragraph.", "Third page paragraph.")
    (c,) = chunk_pages(pgs, max_chars=500, overlap_chars=0)
    assert (c.page_start, c.page_end, c.pages) == (1, 3, [1, 2, 3])


def test_page_numbers_and_engines_follow_pages_not_positions():
    pgs = [Page(number=5, text="Alpha text here.", engine="pymupdf"),
           Page(number=9, text="Beta text here.", engine="mineru-standard")]
    (c,) = chunk_pages(pgs, max_chars=500, overlap_chars=0)
    assert c.pages == [5, 9] and c.engines == ["pymupdf", "mineru-standard"]


def test_pdf_style_text_without_blank_lines():
    text = "\n".join(f"line {i} of wrapped pdf text that goes on" for i in range(200))
    pgs = pages(text)
    chunks = chunk_pages(pgs, max_chars=300, overlap_chars=60)
    check_invariants(pgs, chunks, 300)
    assert all(not c.text.startswith(" ") for c in chunks)


def test_heading_path_and_section_split():
    md = ("# Guide\n\nIntro paragraph " + "x" * 200 + ".\n\n## Install\n\nInstall steps " + "y" * 200 +
          ".\n\n### Linux\n\nLinux notes " + "z" * 50 + ".\n\n## Usage\n\nUsage text.")
    pgs = pages(md)
    chunks = chunk_pages(pgs, max_chars=1000, overlap_chars=100, min_chars=100)
    check_invariants(pgs, chunks, 1000)
    by_start = {c.text.split("\n")[0]: c for c in chunks}
    assert by_start["## Install"].heading_path == ["Guide", "Install"]
    assert by_start["## Usage"].heading_path == ["Guide", "Usage"]
    # no overlap across a section break
    assert by_start["## Usage"].overlap_chars == 0 and by_start["## Install"].overlap_chars == 0


def test_heading_path_persists_across_pages():
    pgs = pages("# Title\n\n## Part A\n\nText on page one.", "More text for part A on page two.")
    chunks = chunk_pages(pgs, max_chars=40, overlap_chars=0)
    assert chunks[-1].page_start == 2
    assert chunks[-1].heading_path == ["Title", "Part A"]


def test_heading_is_not_stranded_at_chunk_end():
    body = "word " * 55  # ~275 chars, so the next heading would just overflow
    md = f"{body.strip()}.\n\n### Subsection title\n\nContent under the subsection."
    chunks = chunk_pages(pages(md), max_chars=300, overlap_chars=0, split_heading_level=0)
    assert len(chunks) == 2
    assert not chunks[0].text.rstrip().endswith("Subsection title")
    assert chunks[1].text.startswith("### Subsection title")


def test_table_and_code_stay_whole_when_they_fit():
    table = "| a | b |\n|---|---|\n" + "\n".join(f"| {i} | {i * 2} |" for i in range(8))
    code = "```python\nprint('hi')\n\nprint('there')\n```"
    md = ("Filler sentence. " * 15) + "\n\n" + table + "\n\n" + code + "\n\nAfter."
    pgs = pages(md)
    chunks = chunk_pages(pgs, max_chars=300, overlap_chars=0)
    check_invariants(pgs, chunks, 300)
    assert any(table in c.text and "table" in c.content_types for c in chunks)
    assert any(code in c.text and "code" in c.content_types for c in chunks)


def test_oversized_table_splits_on_row_boundaries():
    table = "| a | b |\n|---|---|\n" + "\n".join(f"| row{i} | value{i} |" for i in range(100))
    pgs = pages(table)
    chunks = chunk_pages(pgs, max_chars=200, overlap_chars=0)
    check_invariants(pgs, chunks, 200)
    for c in chunks:
        assert all(line.startswith("|") and line.endswith("|") for line in c.text.splitlines())


def test_unbroken_token_is_hard_split():
    blob = "A" * 1000
    pgs = pages(f"before {blob} after")
    chunks = chunk_pages(pgs, max_chars=100, overlap_chars=0)
    check_invariants(pgs, chunks, 100)
    assert "".join(c.text.replace(" ", "") for c in chunks) == f"before{blob}after"


def test_cjk_sentences_split_without_spaces():
    pgs = pages("这是第一句话。" * 60)
    chunks = chunk_pages(pgs, max_chars=50, overlap_chars=0)
    check_invariants(pgs, chunks, 50)
    assert all(c.text.endswith("。") for c in chunks)


def test_ids_are_deterministic_and_content_sensitive():
    pgs = pages(make_prose(30))
    a = chunk_pages(pgs, source="doc", max_chars=300)
    b = chunk_pages(pgs, source="doc", max_chars=300)
    assert [c.chunk_id for c in a] == [c.chunk_id for c in b]
    assert len({c.chunk_id for c in a}) == len(a)
    other = chunk_pages(pgs, source="other", max_chars=300)
    assert a[0].chunk_id != other[0].chunk_id and a[0].text_hash == other[0].text_hash


def test_parse_result_api_returns_models_and_dicts():
    result = ParseResult(source="x.pdf", pages=pages(make_prose(20)))
    models, dicts = result.chunk(300), result.chunks(300)
    assert [m.model_dump() for m in models] == dicts
    assert dicts[0]["source"] == "x.pdf" and "start_char" in dicts[0]


@pytest.mark.parametrize("kwargs", [
    {"max_chars": 0}, {"max_chars": 10, "overlap_chars": 10}, {"max_chars": 10, "overlap_chars": -1},
    {"split_heading_level": -1},
])
def test_invalid_arguments(kwargs):
    with pytest.raises(ValueError):
        chunk_pages(pages("text"), **kwargs)


def test_scales_linearly_enough():
    pgs = pages(*[make_prose(400) for _ in range(250)])  # ~5 MB
    start = time.perf_counter()
    chunks = chunk_pages(pgs, max_chars=1500, overlap_chars=150)
    elapsed = time.perf_counter() - start
    assert len(chunks) > 3000
    assert elapsed < 15, elapsed
