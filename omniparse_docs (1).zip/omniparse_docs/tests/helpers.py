import textwrap

from omniparse.layout import Line, RawBlock
from omniparse.models import Page, ParseResult


def pages(*texts, engine="test"):
    return [Page(number=i + 1, text=t, engine=engine) for i, t in enumerate(texts)]


def check_invariants(pgs, chunks, max_chars):
    doc = ParseResult(source="s", pages=pgs).markdown
    assert [c.index for c in chunks] == list(range(len(chunks)))
    covered = 0
    for i, c in enumerate(chunks):
        assert c.text == doc[c.start_char:c.end_char]          # exact slice -> citable
        assert 0 < len(c.text) <= max_chars                    # size bound incl. overlap
        assert c.total_chunks == len(chunks)
        assert c.prev_id == (chunks[i - 1].chunk_id if i else None)
        assert c.next_id == (chunks[i + 1].chunk_id if i + 1 < len(chunks) else None)
        assert c.page_start <= c.page_end and c.pages == sorted(c.pages)
        if i:
            assert c.start_char >= chunks[i - 1].start_char     # ordered
            assert c.end_char > chunks[i - 1].end_char          # always progresses
        # nothing lost: any gap between coverage must be whitespace
        assert doc[covered:max(covered, c.start_char)].strip() == ""
        covered = max(covered, c.end_char)
    assert doc[covered:].strip() == ""
    return doc


def make_prose(n_sentences):
    return " ".join(f"Sentence number {i} talks about topic {i % 7} in some detail." for i in range(n_sentences))


def para(text, x0, y0, width, size=11.0, bold=False, mono=False):
    """A RawBlock of wrapped lines (no inter-line gap, so it stays one paragraph)."""
    per_line = max(1, int(width / (size * 0.5)))
    lines, y = [], y0
    for chunk in textwrap.wrap(text, per_line):
        lines.append(Line(chunk, x0, y, x0 + len(chunk) * size * 0.5, y + size * 1.2, size, bold, mono))
        y += size * 1.2
    return RawBlock(bbox=(x0, y0, x0 + width, y), lines=lines)
