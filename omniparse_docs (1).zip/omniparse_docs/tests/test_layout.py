import pytest

from helpers import check_invariants, para
from omniparse.chunking import chunk_pages
from omniparse.layout import Line, RawBlock, RawPage, build_pages, reading_order, table_to_markdown

W, H = 600.0, 800.0
BODY = "Body text of the document continues here with enough words to dominate the font statistics. " * 2


def build(*raw_pages):
    return build_pages([RawPage(W, H, blocks) for blocks in raw_pages], engine="test")


def kinds(page):
    return [(b.kind, b.text[:12]) for b in page.blocks if b.start is not None]


def test_two_columns_are_read_column_by_column():
    blocks = [para(f"{side}{i} {BODY}", x, 100 + i * 150, 230)
              for i in (0, 1, 2) for side, x in (("L", 50), ("R", 320))]
    (page,) = build(blocks)
    order = [b.text[:2] for b in page.blocks]
    assert order == ["L0", "L1", "L2", "R0", "R1", "R2"]
    assert [b.column for b in page.blocks] == [0, 0, 0, 1, 1, 1]
    assert [b.order for b in page.blocks] == list(range(6))


def test_full_width_blocks_separate_column_bands():
    blocks = [para("Title spanning the page " * 3, 50, 40, 500, size=11)]
    blocks += [para(f"{s}{i} {BODY}", x, 100 + i * 100, 230) for i in (0, 1) for s, x in (("L", 50), ("R", 320))]
    blocks += [para("Conclusion spanning both columns " * 3, 50, 400, 500)]
    (page,) = build(blocks)
    assert [b.text[:3] for b in page.blocks] == ["Tit", "L0 ", "L1 ", "R0 ", "R1 ", "Con"]


def test_heading_overhanging_the_gutter_does_not_merge_columns():
    title = para("A Fairly Long Title", 50, 40, 277, size=22)  # ends at x=327, past the gutter at 280-320
    cols = [para(f"{s}{i} {BODY}", x, 100 + i * 150, 230) for i in (0, 1) for s, x in (("L", 50), ("R", 320))]
    (page,) = build([title, *cols])
    assert [(b.text[:2], b.column) for b in page.blocks] == [
        ("A ", 0), ("L0", 0), ("L1", 0), ("R0", 1), ("R1", 1)]


def test_centered_title_over_both_columns_is_a_spanner():
    title = para("Title centered above both columns", 150, 40, 300, size=14)
    cols = [para(f"{s}{i} {BODY}", x, 100 + i * 150, 230) for i in (0, 1) for s, x in (("L", 50), ("R", 320))]
    (page,) = build([*cols[::-1], title])
    assert [b.text[:2] for b in page.blocks] == ["Ti", "L0", "L1", "R0", "R1"]
    assert page.blocks[0].column == 0


def test_single_column_page_keeps_top_to_bottom_order():
    blocks = [para(f"P{i} {BODY}", 72, 100 + i * 120, 456) for i in (2, 0, 1)]  # given out of order
    (page,) = build(blocks)
    assert [b.text[:2] for b in page.blocks] == ["P0", "P1", "P2"]
    assert {b.column for b in page.blocks} == {0}


def test_heading_levels_follow_font_size_ladder():
    blocks = [para("Annual Report", 72, 60, 456, size=24),
              para(BODY, 72, 120, 456),
              para("Methods", 72, 260, 456, size=16),
              para(BODY, 72, 300, 456),
              para("Data sources", 72, 440, 456, size=11, bold=True),
              para(BODY, 72, 480, 456)]
    (page,) = build(blocks)
    heads = [(b.text, b.level) for b in page.blocks if b.kind == "heading"]
    assert heads == [("Annual Report", 1), ("Methods", 2), ("Data sources", 3)]
    assert page.text.startswith("# Annual Report\n\n")
    assert "\n\n## Methods\n\n" in page.text and "\n\n### Data sources\n\n" in page.text


def test_long_bold_sentence_is_not_a_heading():
    (page,) = build([para(BODY, 72, 100, 456), para("This bold remark is a full sentence.", 72, 300, 456, bold=True)])
    assert all(b.kind != "heading" for b in page.blocks)


def test_fused_block_is_split_into_paragraphs_and_dehyphenated():
    lines = [Line("This paragraph wraps with a hyphen-", 72, 100, 400, 113, 11),
             Line("ated word and ends here.", 72, 113, 300, 126, 11),
             Line("A second paragraph follows after a gap.", 72, 140, 400, 153, 11)]
    (page,) = build([RawBlock(bbox=(72, 100, 400, 153), lines=lines)])
    assert [b.text for b in page.blocks] == ["This paragraph wraps with a hyphenated word and ends here.",
                                              "A second paragraph follows after a gap."]


def test_first_line_indent_starts_new_paragraph():
    lines = [Line("First paragraph ends here.", 72, 100, 400, 113, 11),
             Line("Second starts with an indent", 90, 113, 400, 126, 11),
             Line("and continues on this line.", 72, 126, 400, 139, 11)]
    (page,) = build([RawBlock(bbox=(72, 100, 400, 139), lines=lines)])
    assert len(page.blocks) == 2


def test_lists_are_detected_and_bullets_normalised():
    lines = [Line("• first item that is long", 72, 100, 300, 113, 11),
             Line("wraps onto a second line", 80, 113, 300, 126, 11),
             Line("• second item", 72, 126, 300, 139, 11)]
    (page,) = build([para(BODY, 72, 40, 456), RawBlock(bbox=(72, 100, 300, 139), lines=lines)])
    lst = [b for b in page.blocks if b.kind == "list"][0]
    assert lst.text == "- first item that is long wraps onto a second line\n- second item"


def test_captions_are_recognised_but_prose_mentions_are_not():
    (page,) = build([para("Table 2: Quarterly revenue by region", 72, 100, 456),
                     para("Figure 3 shows that revenue grew steadily over the whole period.", 72, 200, 456),
                     para(BODY, 72, 300, 456)])
    assert [b.kind for b in page.blocks] == ["caption", "paragraph", "paragraph"]


def test_monospace_blocks_become_fenced_code():
    code_lines = [Line("x = 1", 72, 200, 120, 213, 10, mono=True), Line("y = 2", 72, 213, 120, 226, 10, mono=True)]
    (page,) = build([para(BODY, 72, 40, 456), RawBlock(bbox=(72, 200, 120, 226), lines=code_lines)])
    code = [b for b in page.blocks if b.kind == "code"][0]
    assert page.text[code.start:code.end] == "```\nx = 1\ny = 2\n```"


def test_running_headers_footers_and_page_numbers_are_removed():
    def page(n):
        return [para("ACME Annual Report 2026", 72, 20, 300),
                para(f"Content of page {n}. {BODY}", 72, 200, 456),
                para("Confidential", 72, 760, 200),
                para(str(n), 300, 775, 20)]
    pages_ = build(*[page(n) for n in range(1, 5)])
    for p in pages_:
        assert "ACME" not in p.text and "Confidential" not in p.text
        assert p.text.startswith("Content of page")
        assert sorted(b.kind for b in p.blocks if b.start is None) == ["footer", "footer", "header"]
        assert all(b.end is None for b in p.blocks if b.start is None)


def test_text_repeated_on_too_few_pages_is_kept_and_lone_page_number_removed():
    raw = [[para("Special note", 72, 20, 200), para(BODY, 72, 200, 456), para("7", 300, 775, 20)],
           [para("Special note", 72, 20, 200), para(BODY, 72, 200, 456)],
           [para(BODY, 72, 200, 456)], [para(BODY, 72, 200, 456)]]
    p1 = build(*raw)[0]
    assert "Special note" in p1.text and "\n7" not in p1.text and not p1.text.endswith("7")


def test_block_spans_index_page_text_exactly():
    blocks = [para("Heading Here", 72, 40, 456, size=18), para(BODY, 72, 100, 456),
              RawBlock(bbox=(72, 300, 500, 340), kind="table", text="| a | b |\n|---|---|\n| 1 | 2 |")]
    (page,) = build(blocks)
    for b in page.blocks:
        piece = page.text[b.start:b.end]
        assert piece == ("# Heading Here" if b.kind == "heading" else b.text)


def test_table_to_markdown_handles_ragged_rows_none_and_pipes():
    md = table_to_markdown([["Name", "Note"], ["a|b", None, "extra"], [None, None], ["x\ny", "z"]])
    assert md.splitlines() == ["| Name | Note |  |", "|---|---|---|", "| a\\|b |  | extra |", "| x y | z |  |"]
    assert table_to_markdown([[None, ""], []]) == ""


def test_two_columns_with_one_block_each_are_still_columns():
    left = para("L " + BODY * 2, 50, 100, 230)
    right = para("R " + BODY * 2, 320, 100, 230)
    (page,) = build([right, left])
    assert [(b.text[:1], b.column) for b in page.blocks] == [("L", 0), ("R", 1)]


def test_paragraph_split_does_not_depend_on_tight_line_boxes():
    # line boxes 8pt tall on a 13pt pitch: a fixed gap-vs-height rule would split every line
    lines = [Line(f"line {i} of one flowing paragraph", 72, 100 + 13 * i, 400, 108 + 13 * i, 11) for i in range(5)]
    (page,) = build([RawBlock(bbox=(72, 100, 400, 160), lines=lines)])
    assert len(page.blocks) == 1


def test_reading_order_ignores_stray_narrow_blocks_on_single_column_page():
    heading = para("Short title", 72, 50, 120)
    date = para("27 Oct 2026", 450, 50, 80)
    body = para(BODY, 72, 100, 456)
    assert [b.lines[0].text[:5] for b, _ in reading_order([date, body, heading], W)] == ["Short", "27 Oc", "Body "]


# ------------------------------------------------------------------ layout -> chunks

def document():
    def page(n, extra):
        blocks = [para("ACME Annual Report 2026", 72, 20, 300), para(str(n), 300, 775, 20)]
        blocks += extra
        return blocks
    p1 = page(1, [para("Annual Report", 50, 60, 500, size=24),
                  para("Results", 50, 110, 500, size=16),
                  para("LEFT-ONE " + BODY * 3, 50, 150, 230), para("LEFT-TWO " + BODY * 3, 50, 400, 230),
                  para("RIGHT-ONE " + BODY * 3, 320, 150, 230), para("RIGHT-TWO " + BODY * 3, 320, 400, 230)])
    p2 = page(2, [para("Table 1: Revenue by region", 72, 100, 456),
                  RawBlock(bbox=(72, 130, 500, 230), kind="table",
                           text=table_to_markdown([["Region", "Revenue"], ["EMEA", "10"], ["APAC", "12"]])),
                  para("Methods", 72, 260, 456, size=16),
                  para("After the table. " + BODY * 3, 72, 300, 456)])
    p3 = page(3, [para("Closing remarks. " + BODY, 72, 100, 456)])
    return build_pages([RawPage(W, H, b) for b in (p1, p2, p3)], engine="test")


def test_layout_pages_chunk_with_reading_order_headings_and_isolated_tables():
    pgs = document()
    chunks = chunk_pages(pgs, source="doc.pdf", max_chars=700, overlap_chars=80)
    check_invariants(pgs, chunks, 700)
    joined = "\n".join(c.text for c in chunks)
    assert "ACME" not in joined
    # columns are never interleaved: both LEFT sections precede both RIGHT sections
    pos = {k: joined.index(k) for k in ("LEFT-ONE", "LEFT-TWO", "RIGHT-ONE", "RIGHT-TWO")}
    assert pos["LEFT-ONE"] < pos["LEFT-TWO"] < pos["RIGHT-ONE"] < pos["RIGHT-TWO"]
    # the table lives alone with its caption, never packed with prose
    (table_chunk,) = [c for c in chunks if "table" in c.content_types]
    assert table_chunk.content_types == ["caption", "table"]
    assert table_chunk.text.startswith("Table 1: Revenue by region\n\n| Region | Revenue |")
    assert table_chunk.pages == [2] and table_chunk.overlap_chars == 0
    # heading breadcrumb and regions
    assert table_chunk.heading_path == ["Annual Report", "Results"]
    methods = [c for c in chunks if c.heading_path[-1:] == ["Methods"]]
    assert methods and methods[0].text.startswith("## Methods")
    assert methods[0].heading_path == ["Annual Report", "Results", "Methods"] or methods[0].heading_path == ["Annual Report", "Methods"]
    assert all(c.regions for c in chunks)
    assert table_chunk.regions[0].page == 2 and table_chunk.regions[0].bbox[0] <= 72


def test_isolate_tables_can_be_disabled():
    pgs = document()
    chunks = chunk_pages(pgs, max_chars=1500, overlap_chars=0, isolate_tables=False)
    check_invariants(pgs, chunks, 1500)
    assert any("table" in c.content_types and "text" in c.content_types for c in chunks)


def test_caption_below_table_stays_with_it():
    blocks = [para(BODY, 72, 60, 456),
              RawBlock(bbox=(72, 200, 500, 260), kind="table", text="| a | b |\n|---|---|\n| 1 | 2 |"),
              para("Table 4. Caption placed below the table", 72, 270, 456),
              para("Following paragraph. " + BODY, 72, 330, 456)]
    pgs = build_pages([RawPage(W, H, blocks)], engine="test")
    chunks = chunk_pages(pgs, max_chars=1000, overlap_chars=0)
    check_invariants(pgs, chunks, 1000)
    (t,) = [c for c in chunks if "table" in c.content_types]
    assert t.text.endswith("Table 4. Caption placed below the table") and "Following" not in t.text


def test_oversized_table_splits_on_rows_and_each_piece_is_a_table_chunk():
    rows = [["id", "value"]] + [[str(i), f"value-{i}"] for i in range(120)]
    blocks = [RawBlock(bbox=(72, 100, 500, 700), kind="table", text=table_to_markdown(rows))]
    pgs = build_pages([RawPage(W, H, blocks)], engine="test")
    chunks = chunk_pages(pgs, max_chars=300, overlap_chars=0)
    check_invariants(pgs, chunks, 300)
    assert len(chunks) > 3 and all(c.content_types == ["table"] for c in chunks)
    assert all(line.startswith("|") for c in chunks for line in c.text.splitlines())
