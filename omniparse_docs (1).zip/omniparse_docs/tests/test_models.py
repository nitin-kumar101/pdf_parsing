from omniparse.models import Page, ParseResult

def test_chunks_keep_page_and_engine():
    result = ParseResult(source="sample.pdf", pages=[Page(number=2, text="abcdef", engine="test")])
    (chunk,) = result.chunks(100)
    assert chunk["text"] == "abcdef"
    assert (chunk["page_start"], chunk["page_end"], chunk["pages"]) == (2, 2, [2])
    assert chunk["engines"] == ["test"]
    assert chunk["source"] == "sample.pdf"

def test_chunks_rejects_bad_max_chars():
    import pytest
    with pytest.raises(ValueError):
        ParseResult(source="x", pages=[]).chunks(0)
