"""End-to-end check of the PyMuPDF adapter. Skipped automatically when PyMuPDF is not installed."""
import pytest

fitz = pytest.importorskip("fitz")

from omniparse import DocumentParser

BODY = "Retrieval quality depends on coherent chunks that follow the page layout. " * 6


def make_pdf(path):
    doc = fitz.open()
    for n in (1, 2, 3):
        page = doc.new_page()  # A4, 595 x 842
        page.insert_text((50, 30), "ACME Research Journal", fontsize=8)  # running header
        page.insert_text((290, 820), str(n), fontsize=8)  # page number
        if n == 1:
            page.insert_text((50, 100), "Big Title", fontsize=22)
        page.insert_textbox(fitz.Rect(50, 130, 280, 780), f"L{n}-START {BODY} L{n}-END", fontsize=11)
        page.insert_textbox(fitz.Rect(320, 130, 550, 780), f"R{n}-START {BODY} R{n}-END", fontsize=11)
    doc.save(path)
    doc.close()


def test_layout_extraction_orders_columns_and_drops_furniture(tmp_path):
    pdf = tmp_path / "two_columns.pdf"
    make_pdf(pdf)
    result = DocumentParser(mode="fast").parse(pdf)
    text = result.markdown

    assert result.metadata["layout"] is True
    assert "ACME" not in text
    # each column is read to its end before the next one starts (flat extraction interleaves them)
    assert text.index("L1-START") < text.index("L1-END") < text.index("R1-START") < text.index("R1-END") < text.index("L2-START")
    assert any(b.kind == "heading" and b.text == "Big Title" and b.level == 1 for b in result.pages[0].blocks)
    assert {b.kind for b in result.pages[0].blocks if b.start is None} == {"header", "footer"}

    chunks = result.chunk(max_chars=600)
    assert all("ACME" not in c.text for c in chunks)
    assert [c.start_char for c in chunks] == sorted(c.start_char for c in chunks)
    assert all(c.regions and c.page_start in (1, 2, 3) for c in chunks)
    assert chunks[0].heading_path == ["Big Title"]


def test_layout_can_be_disabled(tmp_path):
    pdf = tmp_path / "flat.pdf"
    make_pdf(pdf)
    result = DocumentParser(mode="fast", layout=False).parse(pdf)
    assert result.metadata["layout"] is False and "ACME" in result.markdown
