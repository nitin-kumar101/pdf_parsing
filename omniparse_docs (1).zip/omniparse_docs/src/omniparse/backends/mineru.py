import subprocess
import tempfile
from pathlib import Path
from ..models import Page

def parse_pdf(path: str, tier: str = "standard") -> list[Page]:
    if tier not in {"flash", "standard", "pro"}:
        raise ValueError("Unsupported MinerU tier")
    with tempfile.TemporaryDirectory() as directory:
        output = Path(directory) / "parsed.md"
        subprocess.run(["mineru-kit", "parse", str(Path(path).resolve()), "-o", str(output), "--tier", tier], check=True, timeout=1800, capture_output=True, text=True)
        return [Page(number=1, text=output.read_text(encoding="utf-8"), engine=f"mineru-{tier}")]
