import warnings

import fitz

from .. import layout
from ..models import Page

_MONO = ("mono", "courier", "consolas", "menlo", "typewriter", "code")


def _flat(doc) -> list[Page]:
    return [Page(number=i + 1, text=page.get_text(sort=True), engine="pymupdf") for i, page in enumerate(doc)]


def _tables(page) -> list[layout.RawBlock]:
    """Tables as pre-rendered Markdown blocks. Table detection is best-effort."""
    try:
        found = page.find_tables().tables
    except Exception:  # older PyMuPDF without find_tables, or a page it cannot analyse
        return []
    out = []
    for table in found:
        markdown = layout.table_to_markdown(table.extract())
        if markdown:
            out.append(layout.RawBlock(bbox=tuple(table.bbox), kind="table", text=markdown))
    return out


def _raw_page(page) -> layout.RawPage:
    tables = _tables(page)
    # Skip image payloads: they are large and irrelevant to text layout.
    data = page.get_text("dict", flags=fitz.TEXTFLAGS_DICT & ~fitz.TEXT_PRESERVE_IMAGES)
    blocks = list(tables)
    for block in data["blocks"]:
        if block.get("type") != 0:
            continue
        x0, y0, x1, y1 = block["bbox"]
        cx, cy = (x0 + x1) / 2, (y0 + y1) / 2
        if any(t.bbox[0] <= cx <= t.bbox[2] and t.bbox[1] <= cy <= t.bbox[3] for t in tables):
            continue  # its text is already inside a rendered table
        lines = []
        for line in block["lines"]:
            spans = [s for s in line["spans"] if s["text"].strip()]
            if not spans:
                continue
            lx0, ly0, lx1, ly1 = line["bbox"]
            lines.append(layout.Line(
                text="".join(s["text"] for s in line["spans"]).strip(),
                x0=lx0, y0=ly0, x1=lx1, y1=ly1,
                size=max(s["size"] for s in spans),
                bold=all(bool(s["flags"] & 16) or "bold" in s["font"].lower() for s in spans),
                mono=all(any(m in s["font"].lower() for m in _MONO) or bool(s["flags"] & 8) for s in spans),
            ))
        if lines:
            blocks.append(layout.RawBlock(bbox=(x0, y0, x1, y1), lines=lines))
    return layout.RawPage(width=page.rect.width, height=page.rect.height, blocks=blocks)


def parse_pdf(path: str, layout_aware: bool = True) -> list[Page]:
    with fitz.open(path) as doc:
        if not layout_aware:
            return _flat(doc)
        try:
            return layout.build_pages([_raw_page(page) for page in doc], engine="pymupdf")
        except Exception as exc:  # never lose the document because layout analysis failed
            warnings.warn(f"layout analysis failed ({exc!r}); falling back to flat text extraction")
            return _flat(doc)
