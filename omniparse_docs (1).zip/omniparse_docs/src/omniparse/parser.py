from pathlib import Path
from .models import ParseResult
from .backends.pymupdf import parse_pdf

class DocumentParser:
    def __init__(self, mode: str = "auto", *, mineru_tier: str = "standard", aws_region: str | None = None, layout: bool = True):
        if mode not in {"auto", "fast", "mineru", "textract"}:
            raise ValueError(f"Unsupported mode: {mode}")
        self.mode = mode
        self.mineru_tier = mineru_tier
        self.aws_region = aws_region
        self.layout = layout  # native PDF path: column/heading/table-aware extraction

    def parse(self, path: str | Path) -> ParseResult:
        path = Path(path).expanduser().resolve(strict=True)
        suffix = path.suffix.lower()
        if suffix == ".pdf":
            if self.mode == "textract":
                raise ValueError("Textract PDF support requires an asynchronous S3 workflow; use image input or another mode")
            if self.mode == "mineru":
                from .backends.mineru import parse_pdf as parse_mineru
                pages = parse_mineru(str(path), self.mineru_tier)
            else:
                pages = parse_pdf(str(path), layout_aware=self.layout)
                if self.mode == "auto" and pages and sum(bool(p.text.strip()) for p in pages) / len(pages) < 0.7:
                    try:
                        from .backends.mineru import parse_pdf as parse_mineru
                        pages = parse_mineru(str(path), self.mineru_tier)
                    except (FileNotFoundError, ImportError):
                        pass  # Preserve available native text; expose OCR needs in metadata
            return ParseResult(source=str(path), pages=pages, metadata={"pages": len(pages), "ocr_may_be_needed": any(not p.text.strip() for p in pages), "layout": any(p.blocks for p in pages)})
        if suffix in {".png", ".jpg", ".jpeg"} and self.mode == "textract":
            from .backends.textract import parse_image
            return ParseResult(source=str(path), pages=parse_image(str(path), self.aws_region))
        raise ValueError(f"Unsupported format/mode: {suffix}/{self.mode}. Office adapters are planned, not implemented in this starter.")
