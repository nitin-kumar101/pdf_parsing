"""Structure-aware chunking with sequence and provenance metadata.

Design
------
* Chunks are cut on semantic boundaries, never mid-word unless a single token is
  longer than ``max_chars`` (e.g. a base64 blob). Preference order for splitting an
  oversized block: sentence -> line -> word -> hard slice.
* Small neighbouring paragraphs are packed together up to ``max_chars``; chunks may
  span page boundaries, so a paragraph continuing onto the next page is not orphaned.
* Layout is respected. When a page carries layout ``blocks`` (see ``omniparse.layout``)
  those are the atoms, in reading order, so multi-column text is never interleaved and
  running headers/footers never enter a chunk. Pages without blocks fall back to
  scanning the Markdown. Either way: headings feed a ``heading_path`` breadcrumb and are
  never stranded at the end of a chunk, a caption stays with its table, tables get their
  own chunk(s) and code stays whole when it fits, and a new chunk starts at a top-level
  heading once the current one has enough content.
* Overlap is made of whole units from the end of the previous chunk (not raw
  characters), and is never carried across a section break.
* Every chunk is an exact slice of the document text: ``result.markdown[c.start_char:c.end_char] == c.text``.
  That makes citations, highlighting and re-assembly trivial and lets tests verify
  that nothing was lost.
* Cost is linear in document size: text is scanned once, spans are tracked as integer
  offsets and the text is only copied once per emitted chunk.
"""
from __future__ import annotations

import hashlib
import re
from dataclasses import dataclass
from typing import Iterator, Sequence

from pydantic import BaseModel, Field

PAGE_SEPARATOR = "\n\n"  # must match ParseResult.markdown


class Region(BaseModel):
    """Where (part of) a chunk sits on a page: the union bbox of its layout blocks."""
    page: int
    bbox: list[float]  # [x0, y0, x1, y1]


class Chunk(BaseModel):
    # identity and sequence
    chunk_id: str  # deterministic: same source + position + text -> same id
    index: int  # 0-based position in the document
    total_chunks: int
    prev_id: str | None = None
    next_id: str | None = None
    source: str = ""
    # content
    text: str
    text_hash: str  # hash of ``text`` alone; use for dedupe / skipping re-embedding
    char_count: int
    token_estimate: int  # rough (chars / 4); swap for a real tokenizer if you need exact
    # location, as offsets into ``ParseResult.markdown``
    start_char: int
    end_char: int
    overlap_chars: int = 0  # ``text[:overlap_chars]`` repeats the end of the previous chunk
    # provenance
    page_start: int
    page_end: int
    pages: list[int] = Field(default_factory=list)
    engines: list[str] = Field(default_factory=list)
    heading_path: list[str] = Field(default_factory=list)  # section at the chunk's first new content
    content_types: list[str] = Field(default_factory=list)  # subset of text/heading/list/code/table/caption
    regions: list[Region] = Field(default_factory=list)  # per-page bbox of the chunk's own content (not overlap)


# --------------------------------------------------------------------------- parsing

_FENCE = re.compile(r"(`{3,}|~{3,})")
_HEADING = re.compile(r"(#{1,6})[ \t]+(.*?)[ \t]*#*")
_SENTENCE = re.compile(r"(?<=[.!?])\s+(?=[^\sa-z])|(?<=[。！？])\s*")
_LINE = re.compile(r"\n+")
_WORD = re.compile(r"\s+")
_SPLITTERS = (_SENTENCE, _LINE, _WORD)


@dataclass(slots=True)
class _Atom:
    start: int  # document offsets
    end: int
    page: int  # index into the pages sequence
    kind: str  # text | heading | list | code | table | caption
    level: int  # heading level, else 0
    path: tuple[str, ...]  # heading breadcrumb in effect at this atom
    block: int = 0  # id of the source block (atoms from one oversized block share it)
    bbox: tuple[float, float, float, float] | None = None


def _trim(text: str, a: int, b: int) -> tuple[int, int]:
    while a < b and text[a].isspace():
        a += 1
    while b > a and text[b - 1].isspace():
        b -= 1
    return a, b


def _blocks(text: str) -> Iterator[tuple[str, int, int, int, str]]:
    """Single pass over a page: yield (kind, start, end, heading_level, heading_title)."""
    pos = 0
    kind: str | None = None
    start = end = 0
    fence = ""

    def close():
        nonlocal kind
        out = (kind, start, end, 0, "") if kind else None
        kind = None
        return out

    for line in text.splitlines(keepends=True):
        line_start = pos
        pos += len(line)
        stripped = line.strip()
        content_start = line_start + (len(line) - len(line.lstrip()))
        content_end = line_start + len(line.rstrip())

        if fence:  # inside a fenced code block
            end = content_end
            if stripped.startswith(fence):
                fence = ""
                done = close()
                if done:
                    yield done
            continue
        if not stripped:
            done = close()
            if done:
                yield done
            continue
        fence_match = _FENCE.match(stripped)
        if fence_match:
            done = close()
            if done:
                yield done
            fence = fence_match.group(1)[:3]
            kind, start, end = "code", content_start, content_end
            continue
        heading = _HEADING.fullmatch(stripped)
        if heading and heading.group(2):
            done = close()
            if done:
                yield done
            yield "heading", content_start, content_end, len(heading.group(1)), heading.group(2)
            continue
        want = "table" if stripped.startswith("|") else "text"
        if kind != want:
            done = close()
            if done:
                yield done
            kind, start = want, content_start
        end = content_end
    done = close()  # also covers an unterminated code fence
    if done:
        yield done


def _split(text: str, a: int, b: int, limit: int, level: int) -> Iterator[tuple[int, int]]:
    """Split span [a, b) into pieces <= limit, using progressively finer separators."""
    if b - a <= limit:
        yield a, b
        return
    if level >= len(_SPLITTERS):  # one unbroken token longer than the limit
        for s in range(a, b, limit):
            yield s, min(s + limit, b)
        return
    pos = a
    for m in _SPLITTERS[level].finditer(text, a, b):
        yield from _piece(text, pos, m.start(), limit, level)
        pos = m.end()
    yield from _piece(text, pos, b, limit, level)


def _piece(text: str, a: int, b: int, limit: int, level: int) -> Iterator[tuple[int, int]]:
    a, b = _trim(text, a, b)
    if a < b:
        yield from _split(text, a, b, limit, level + 1)


def _atoms(pages: Sequence, offsets: list[int], limit: int) -> Iterator[_Atom]:
    stack: list[tuple[int, str]] = []
    path: tuple[str, ...] = ()
    bid = 0
    for pi, page in enumerate(pages):
        text, base = page.text, offsets[pi]
        layout = [b for b in (getattr(page, "blocks", None) or ()) if b.start is not None]
        if layout:  # backend supplied layout: blocks are already in reading order
            items = ((b.kind, b.start, b.end, b.level, b.text, tuple(b.bbox) if b.bbox else None) for b in layout)
        else:  # no layout: recover structure from the Markdown
            items = ((k, a, b, lv, t, None) for k, a, b, lv, t in _blocks(text))
        for kind, a, b, level, title, bbox in items:
            bid += 1
            if kind == "heading":
                level = max(1, min(level, 6))
                while stack and stack[-1][0] >= level:
                    stack.pop()
                stack.append((level, title))
                path = tuple(t for _, t in stack)
                if b - a <= limit:
                    yield _Atom(base + a, base + b, pi, "heading", level, path, bid, bbox)
                    continue
                kind = "text"  # absurdly long heading: treat as ordinary text
            if kind not in ("code", "table", "list", "caption"):
                kind = "text"
            # structured blocks split by line first; prose by sentence first
            for s_, e_ in _split(text, a, b, limit, 1 if kind in ("code", "table", "list") else 0):
                yield _Atom(base + s_, base + e_, pi, kind, 0, path, bid, bbox)


# --------------------------------------------------------------------------- packing

def chunk_pages(
    pages: Sequence,
    *,
    source: str = "",
    max_chars: int = 1500,
    overlap_chars: int | None = None,
    split_heading_level: int = 2,
    min_chars: int | None = None,
    isolate_tables: bool = True,
) -> list[Chunk]:
    """Chunk ``pages`` (objects with ``number``, ``text``, ``engine``) into ordered ``Chunk``s.

    max_chars            hard upper bound on ``len(chunk.text)`` (overlap included).
    overlap_chars        approximate trailing context repeated at the start of the next
                         chunk, rounded down to whole units. 0 disables overlap.
                         Default: min(150, max_chars // 5).
    split_heading_level  start a new chunk at headings of this level or higher (1 = ``#``
                         only, 2 = ``#``/``##``); 0 disables section-aware splitting.
    min_chars            minimum new content before a heading may force a split
                         (default ``max_chars // 3``).
    isolate_tables       give each table (with its caption) its own chunk(s) instead of
                         packing it together with surrounding prose.
    """
    if max_chars < 1:
        raise ValueError("max_chars must be positive")
    if overlap_chars is None:
        overlap_chars = min(150, max_chars // 5)
    if not 0 <= overlap_chars < max_chars:
        raise ValueError("overlap_chars must be >= 0 and smaller than max_chars")
    if split_heading_level < 0:
        raise ValueError("split_heading_level must be >= 0")
    if min_chars is None:
        min_chars = max_chars // 3

    offsets, pos = [], 0
    for page in pages:
        offsets.append(pos)
        pos += len(page.text) + len(PAGE_SEPARATOR)
    doc = PAGE_SEPARATOR.join(p.text for p in pages)

    # (start, end, own_start, page_idxs, kinds, path) per chunk, in order
    raw: list[tuple[int, int, int, list[int], set[str], tuple[str, ...], dict[int, list[float]]]] = []
    cur: list[_Atom] = []  # leading n_ov atoms are overlap from the previous chunk
    n_ov = 0

    def emit(body: list[_Atom]) -> None:
        pgs: list[int] = []
        kinds: set[str] = set()
        for at in body:
            if not pgs or pgs[-1] != at.page:
                pgs.append(at.page)
            kinds.add(at.kind)
        own = body[n_ov]
        regions: dict[int, list[float]] = {}
        for at in body[n_ov:]:
            if at.bbox:
                r = regions.get(at.page)
                if r is None:
                    regions[at.page] = list(at.bbox)
                else:
                    r[0], r[1] = min(r[0], at.bbox[0]), min(r[1], at.bbox[1])
                    r[2], r[3] = max(r[2], at.bbox[2]), max(r[3], at.bbox[3])
        raw.append((body[0].start, body[-1].end, own.start, pgs, kinds, own.path, regions))

    def is_glue(i: int) -> bool:
        """Atom i belongs with what follows: a heading, or a caption not already attached to a table above."""
        at = cur[i]
        return at.kind == "heading" or (at.kind == "caption" and (i == 0 or cur[i - 1].kind != "table"))

    def flush(keep_overlap: bool) -> None:
        nonlocal cur, n_ov
        cut = len(cur)
        while cut - n_ov > 1 and is_glue(cut - 1):  # never strand a heading/caption at a chunk's end
            cut -= 1
        body, carry = cur[:cut], cur[cut:]
        emit(body)
        tail: list[_Atom] = []
        if keep_overlap and overlap_chars:
            i, end = len(body), body[-1].end
            while i > 0 and end - body[i - 1].start <= overlap_chars:
                i -= 1
            tail = body[i:]
            if len(tail) == len(body):  # overlap must never be the whole previous chunk
                tail = tail[1:]
        cur, n_ov = tail + carry, len(tail)

    for atom in _atoms(pages, offsets, max_chars):
        if isolate_tables and cur:
            last = cur[-1]
            if len(cur) == n_ov:  # only overlap pending: a table starts clean
                if atom.kind == "table":
                    cur.clear()
                    n_ov = 0
            elif last.block != atom.block:
                after_table = last.kind == "table" or (
                    last.kind == "caption" and len(cur) - n_ov >= 2 and cur[-2].kind == "table"
                )
                if after_table and not (atom.kind == "caption" and last.kind == "table"):
                    flush(False)  # table (+ its trailing caption) finished
                elif atom.kind == "table" and not all(is_glue(i) for i in range(n_ov, len(cur))):
                    flush(False)  # table starts its own chunk, taking a lead-in heading/caption along
        while cur and atom.end - cur[0].start > max_chars:
            if n_ov:  # make room by shrinking overlap first
                cur.pop(0)
                n_ov -= 1
            else:
                flush(True)
        if (
            len(cur) > n_ov
            and split_heading_level
            and atom.kind == "heading"
            and atom.level <= split_heading_level
            and cur[-1].end - cur[n_ov].start >= min_chars
        ):
            flush(False)  # section boundary: no overlap across it
        cur.append(atom)
    if len(cur) > n_ov:
        emit(cur)

    total = len(raw)
    ids: list[str] = []
    texts: list[str] = []
    hashes: list[str] = []
    for i, (s, e, *_rest) in enumerate(raw):
        text = doc[s:e]
        digest = hashlib.blake2b(text.encode("utf-8", "surrogatepass"), digest_size=16).hexdigest()
        cid = hashlib.blake2b(f"{source}\0{i}\0{digest}".encode("utf-8", "surrogatepass"), digest_size=8).hexdigest()
        texts.append(text)
        hashes.append(digest)
        ids.append(cid)

    chunks: list[Chunk] = []
    for i, (s, e, own, pgs, kinds, path, regions) in enumerate(raw):
        engines: list[str] = []
        for pi in pgs:
            if pages[pi].engine not in engines:
                engines.append(pages[pi].engine)
        numbers = [pages[pi].number for pi in pgs]
        chunks.append(
            Chunk(
                chunk_id=ids[i],
                index=i,
                total_chunks=total,
                prev_id=ids[i - 1] if i > 0 else None,
                next_id=ids[i + 1] if i + 1 < total else None,
                source=source,
                text=texts[i],
                text_hash=hashes[i],
                char_count=e - s,
                token_estimate=(e - s + 3) // 4,
                start_char=s,
                end_char=e,
                overlap_chars=own - s,
                page_start=numbers[0],
                page_end=numbers[-1],
                pages=numbers,
                engines=engines,
                heading_path=list(path),
                content_types=sorted(kinds),
                regions=[Region(page=pages[pi].number, bbox=[round(v, 2) for v in bb]) for pi, bb in regions.items()],
            )
        )
    return chunks
