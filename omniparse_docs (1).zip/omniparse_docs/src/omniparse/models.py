from pydantic import BaseModel, Field
from .chunking import PAGE_SEPARATOR, Chunk, chunk_pages

class Block(BaseModel):
    """A layout element of a page, in reading order."""
    kind: str  # heading | paragraph | list | table | code | caption | header | footer
    text: str
    bbox: list[float] | None = None  # [x0, y0, x1, y1] in page coordinates
    level: int = 0  # heading level (1 = top)
    order: int = 0  # reading-order position within the page
    column: int = 0  # 0-based column index on multi-column pages
    start: int | None = None  # char span inside Page.text; None for header/footer (excluded from text)
    end: int | None = None

class Page(BaseModel):
    number: int
    text: str
    engine: str
    blocks: list[Block] = Field(default_factory=list)  # empty when the engine gives no layout
    width: float | None = None
    height: float | None = None

class ParseResult(BaseModel):
    source: str
    pages: list[Page] = Field(default_factory=list)
    metadata: dict = Field(default_factory=dict)
    tables: list[dict] = Field(default_factory=list)
    @property
    def markdown(self) -> str:
        return PAGE_SEPARATOR.join(p.text for p in self.pages)
    @property
    def text(self) -> str:
        return self.markdown
    def chunk(self, max_chars: int = 1500, overlap_chars: int | None = None, **options) -> list[Chunk]:
        """Ordered, metadata-rich chunks. See ``omniparse.chunking.chunk_pages`` for options."""
        return chunk_pages(self.pages, source=self.source, max_chars=max_chars, overlap_chars=overlap_chars, **options)

    def chunks(self, max_chars: int = 1500, overlap_chars: int | None = None, **options) -> list[dict]:
        """Same as ``chunk()`` but as plain dicts (JSON-ready)."""
        return [c.model_dump() for c in self.chunk(max_chars, overlap_chars, **options)]
