import json
from pathlib import Path
import typer
from .parser import DocumentParser
app = typer.Typer()

@app.command()
def parse(
    path: Path,
    mode: str = "auto",
    output: Path | None = None,
    format: str = "markdown",
    layout: bool = typer.Option(True, help="Layout-aware native PDF extraction (columns, headings, tables, headers/footers)"),
    max_chars: int = typer.Option(1500, help="Max characters per chunk (chunks format)"),
    overlap: int | None = typer.Option(None, help="Approx. characters of overlap between chunks (default: min(150, max_chars/5))"),
):
    if format not in {"markdown", "json", "chunks"}:
        raise typer.BadParameter("format must be markdown, json or chunks")
    result = DocumentParser(mode=mode, layout=layout).parse(path)
    if format == "markdown":
        content = result.markdown
    elif format == "json":
        content = json.dumps(result.model_dump(), indent=2)
    else:  # JSON Lines: one chunk per line, in document order
        try:
            chunks = result.chunks(max_chars, overlap)
        except ValueError as exc:
            raise typer.BadParameter(str(exc))
        content = "\n".join(json.dumps(c, ensure_ascii=False) for c in chunks)
    if output:
        output.write_text(content, encoding="utf-8")
    else:
        typer.echo(content)
