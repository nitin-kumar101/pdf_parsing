"""Layout analysis: raw positioned text -> ordered, classified ``Block``s.

This module is deliberately free of any PDF library. A backend only has to describe
each page as ``RawBlock``s made of ``Line``s (text + bbox + font size/style); everything
else lives here and is unit-testable with plain data:

* reading order for single and multi-column pages (full-width blocks act as separators),
* heading detection and levels from the document's font-size ladder,
* paragraphs split from fused text blocks (line gaps / first-line indents), de-hyphenation,
* lists, code (monospace), captions, and pre-rendered tables,
* running headers / footers / page numbers detected across pages and kept out of the text.

``build_pages`` renders each page to Markdown and records, for every block, its exact
character span inside ``Page.text`` so the chunker can work on blocks directly.
"""
from __future__ import annotations

import re
import statistics
from collections import Counter
from dataclasses import dataclass, field

from .models import Block, Page

BBox = tuple[float, float, float, float]
BLOCK_SEPARATOR = "\n\n"


@dataclass(slots=True)
class Line:
    text: str
    x0: float
    y0: float
    x1: float
    y1: float
    size: float
    bold: bool = False
    mono: bool = False


@dataclass(slots=True)
class RawBlock:
    bbox: BBox
    lines: list[Line] = field(default_factory=list)
    kind: str = ""  # preset by the backend for non-prose blocks, e.g. "table"
    text: str = ""  # preset text (Markdown) for such blocks


@dataclass(slots=True)
class RawPage:
    width: float
    height: float
    blocks: list[RawBlock]


@dataclass(slots=True)
class _Item:
    kind: str
    text: str
    bbox: BBox
    size: float
    column: int


# --------------------------------------------------------------------------- text helpers

_LIST_ITEM = re.compile(r"^(?:[-•●▪◦■□–·*]|\(?\d{1,3}[.)]|\(?[a-z][.)])\s+")
_BULLET_GLYPH = re.compile(r"^[•●▪◦■□–·*]\s+")
_CAPTION = re.compile(r"^(?:table|figure|fig\.?|chart|exhibit)\s+[\dA-Z][\w-]*(?:\.\d+)*\s*[.:–—-]\s*\S", re.I)
_PAGE_NUMBER = re.compile(r"^\s*(?:page\s+)?\d{1,4}(?:\s*(?:/|of)\s*\d{1,4})?\s*$", re.I)
_DIGITS = re.compile(r"\d+")
_SPACE = re.compile(r"\s+")


def _join(parts: list[str]) -> str:
    """Join wrapped lines; re-attach words broken by an end-of-line hyphen."""
    acc = [parts[0]]
    for nxt in parts[1:]:
        prev = acc[-1]
        if len(prev) >= 2 and prev[-1] == "-" and prev[-2].isalpha() and nxt[:1].islower():
            acc[-1] = prev[:-1]
        else:
            acc.append(" ")
        acc.append(nxt)
    return "".join(acc)


def _join_list(items: list[str]) -> str:
    entries: list[list[str]] = []
    for t in items:
        if _LIST_ITEM.match(t) or not entries:
            entries.append([_BULLET_GLYPH.sub("- ", t)])
        else:
            entries[-1].append(t)  # continuation of the previous item
    return "\n".join(_join(e) for e in entries)


def table_to_markdown(rows: list[list[str | None]]) -> str:
    """Render extracted table rows as a Markdown table ('' if there is nothing to render)."""
    cleaned = [[_SPACE.sub(" ", (c or "")).strip().replace("|", "\\|") for c in r] for r in rows]
    cleaned = [r for r in cleaned if any(r)]
    width = max((len(r) for r in cleaned), default=0)
    if width == 0:
        return ""
    cleaned = [r + [""] * (width - len(r)) for r in cleaned]
    lines = ["| " + " | ".join(cleaned[0]) + " |", "|" + "---|" * width]
    lines += ["| " + " | ".join(r) + " |" for r in cleaned[1:]]
    return "\n".join(lines)


# --------------------------------------------------------------------------- reading order

def _merge_intervals(intervals: list[tuple[float, float]], gap: float) -> list[list[float]]:
    merged: list[list[float]] = []
    for x0, x1 in sorted(intervals):
        if merged and x0 - merged[-1][1] < gap:
            merged[-1][1] = max(merged[-1][1], x1)
        else:
            merged.append([x0, x1])
    return merged


def reading_order(blocks: list[RawBlock], width: float) -> list[tuple[RawBlock, int]]:
    """Order blocks top-to-bottom, but column-by-column on multi-column pages.

    Column boundaries come from body-text blocks (3+ lines, or tables) rather than from
    headings, which may overhang the gutter. A block that is at least 55% of the page wide,
    or substantially covers two or more columns, cannot sit inside a column: it splits the
    page into horizontal bands. Inside a band, columns are read left to right.
    Returns (block, column_index) pairs.
    """
    by_y = sorted(blocks, key=lambda b: (b.bbox[1], b.bbox[0]))
    if width <= 0 or len(blocks) < 2:
        return [(b, 0) for b in by_y]
    wide = 0.55 * width
    body = [b for b in blocks if (len(b.lines) >= 3 or b.kind) and b.bbox[2] - b.bbox[0] < wide]
    cols = _merge_intervals([(b.bbox[0], b.bbox[2]) for b in body], 0.015 * width)

    def weight(c: list[float]) -> int:  # lines of content in the column (a table counts as 4)
        return sum(len(b.lines) or 4 for b in body if c[0] <= (b.bbox[0] + b.bbox[2]) / 2 <= c[1])

    cols = [c for c in cols if weight(c) >= 4]  # a lone title next to a date does not make columns
    if not 2 <= len(cols) <= 4:
        return [(b, 0) for b in by_y]

    def col_of(b: RawBlock) -> int:
        cx = (b.bbox[0] + b.bbox[2]) / 2
        for i, (_, hi) in enumerate(cols):
            if cx <= hi:
                return i
        return len(cols) - 1

    def spans_columns(b: RawBlock) -> bool:
        bw = b.bbox[2] - b.bbox[0]
        if bw >= wide:
            return True
        covered = sum(
            min(b.bbox[2], hi) - max(b.bbox[0], lo) >= 0.25 * min(bw, hi - lo) for lo, hi in cols
        )
        return covered >= 2

    out: list[tuple[RawBlock, int]] = []
    band: list[RawBlock] = []

    def close_band() -> None:
        band.sort(key=lambda b: (col_of(b), b.bbox[1], b.bbox[0]))
        out.extend((b, col_of(b)) for b in band)
        band.clear()

    for b in by_y:
        if spans_columns(b):
            close_band()
            out.append((b, 0))
        else:
            band.append(b)
    close_band()
    return out


# --------------------------------------------------------------------------- classification

def _body_size(pages: list[RawPage]) -> float:
    counts: Counter[float] = Counter()
    for page in pages:
        for b in page.blocks:
            for ln in b.lines:
                counts[round(ln.size * 2) / 2] += len(ln.text)
    return counts.most_common(1)[0][0] if counts else 11.0


def _furniture(pages: list[RawPage]) -> dict[tuple[int, int], str]:
    """Running headers/footers (text repeated across pages) and bare page numbers."""
    found: dict[tuple[int, int], str] = {}
    candidates: list[tuple[int, int, str, tuple[str, str]]] = []
    counts: Counter[tuple[str, str]] = Counter()
    for pi, page in enumerate(pages):
        if page.height <= 0:
            continue
        for bi, b in enumerate(page.blocks):
            if b.kind or not b.lines or len(b.lines) > 2:
                continue
            if b.bbox[3] <= 0.1 * page.height:
                band = "header"
            elif b.bbox[1] >= 0.9 * page.height:
                band = "footer"
            else:
                continue
            text = " ".join(ln.text.strip() for ln in b.lines)
            if _PAGE_NUMBER.match(text):
                found[(pi, bi)] = band
                continue
            key = (band, _SPACE.sub(" ", _DIGITS.sub("#", text.lower())).strip())
            counts[key] += 1
            candidates.append((pi, bi, band, key))
    needed = max(3, -(-len(pages) * 2 // 5))  # at least 3 pages and 40% of the document
    for pi, bi, band, key in candidates:
        if counts[key] >= needed:
            found[(pi, bi)] = band
    return found


def _paragraph_groups(lines: list[Line]) -> list[list[Line]]:
    """Split one fused text block into paragraphs.

    A paragraph break is a line-to-line pitch clearly larger than the block's usual pitch
    (measured between line tops, so it does not depend on how tight the line boxes are),
    or a first-line indent after a sentence end. Needs 3+ lines to estimate the usual pitch.
    """
    if len(lines) < 2 or sum(ln.mono for ln in lines) * 2 > len(lines):
        return [lines]
    pitches = [cur.y0 - prev.y0 for prev, cur in zip(lines, lines[1:])]
    usual = sorted(pitches)[len(pitches) // 3] if len(pitches) >= 2 else float("inf")
    left = min(ln.x0 for ln in lines)
    groups = [[lines[0]]]
    for prev, cur, pitch in zip(lines, lines[1:], pitches):
        indent = cur.x0 - left > 0.8 * cur.size and prev.text.rstrip().endswith((".", "!", "?", ":"))
        if pitch > 1.3 * usual or indent:
            groups.append([cur])
        else:
            groups[-1].append(cur)
    return groups


def _is_heading(text: str, n_lines: int, size: float, bold: bool, body: float) -> bool:
    if n_lines > 3 or len(text) > 200 or not any(c.isalpha() for c in text):
        return False
    if size >= body * 1.12:
        return True
    return bold and size >= body * 0.95 and len(text) <= 120 and not text.endswith((".", ",", ";", ":"))


def _describe(lines: list[Line], body: float) -> tuple[str, str, float]:
    chars = sum(len(ln.text) for ln in lines) or 1
    size = sum(ln.size * len(ln.text) for ln in lines) / chars
    if sum(len(ln.text) for ln in lines if ln.mono) / chars >= 0.8:
        return "code", "\n".join(ln.text.rstrip() for ln in lines), size
    items = [ln.text.strip() for ln in lines]
    if len(items) >= 2 and _LIST_ITEM.match(items[0]) and sum(bool(_LIST_ITEM.match(t)) for t in items) * 2 >= len(items):
        return "list", _join_list(items), size
    text = _join(items)
    if len(text) <= 400 and _CAPTION.match(text):
        return "caption", text, size
    if _is_heading(text, len(lines), size, all(ln.bold for ln in lines), body):
        return "heading", text, round(size * 2) / 2
    return "paragraph", text, size


def _union(lines: list[Line]) -> BBox:
    return (min(l.x0 for l in lines), min(l.y0 for l in lines), max(l.x1 for l in lines), max(l.y1 for l in lines))


def _render(kind: str, text: str, level: int) -> str:
    if kind == "heading":
        return "#" * level + " " + text
    if kind == "code":
        return "```\n" + text + "\n```"
    return text


# --------------------------------------------------------------------------- entry point

def build_pages(raw_pages: list[RawPage], engine: str, first_number: int = 1) -> list[Page]:
    """Turn raw positioned blocks into ``Page``s with Markdown text and layout ``blocks``."""
    body = _body_size(raw_pages)
    furniture = _furniture(raw_pages)

    staged: list[tuple[list[_Item], list[tuple[str, RawBlock]]]] = []
    heading_sizes: set[float] = set()
    for pi, page in enumerate(raw_pages):
        kept = [b for bi, b in enumerate(page.blocks) if (pi, bi) not in furniture and (b.kind or b.lines)]
        items: list[_Item] = []
        for raw, column in reading_order(kept, page.width):
            if raw.kind:  # e.g. a table rendered by the backend
                if raw.text.strip():
                    items.append(_Item(raw.kind, raw.text.strip(), raw.bbox, 0.0, column))
                continue
            for group in _paragraph_groups(raw.lines):
                kind, text, size = _describe(group, body)
                if text.strip():
                    items.append(_Item(kind, text.strip(), _union(group), size, column))
                    if kind == "heading":
                        heading_sizes.add(size)
        removed = [(furniture[(pi, bi)], b) for bi, b in enumerate(page.blocks) if (pi, bi) in furniture]
        staged.append((items, removed))

    ladder = {s: min(i + 1, 6) for i, s in enumerate(sorted(heading_sizes, reverse=True))}

    pages: list[Page] = []
    for pi, (items, removed) in enumerate(staged):
        parts: list[str] = []
        blocks: list[Block] = []
        pos = 0
        for order, it in enumerate(items):
            level = ladder.get(it.size, 6) if it.kind == "heading" else 0
            rendered = _render(it.kind, it.text, level)
            if parts:
                pos += len(BLOCK_SEPARATOR)
            blocks.append(Block(kind=it.kind, text=it.text, bbox=[round(v, 2) for v in it.bbox], level=level,
                                order=order, column=it.column, start=pos, end=pos + len(rendered)))
            parts.append(rendered)
            pos += len(rendered)
        for band, raw in removed:  # kept as metadata only; not part of Page.text
            text = _join([ln.text.strip() for ln in raw.lines])
            blocks.append(Block(kind=band, text=text, bbox=[round(v, 2) for v in raw.bbox]))
        page = raw_pages[pi]
        pages.append(Page(number=first_number + pi, text=BLOCK_SEPARATOR.join(parts), engine=engine,
                          blocks=blocks, width=page.width, height=page.height))
    return pages
