# omniparse-docs (starter)

A lightweight, extensible document parsing starter with a public SDK, CLI and agent skill.

## Install locally

```bash
pip install -e .
pip install -e '.[dev]' && pytest   # tests
# Optional engines
pip install -e '.[mineru]'
pip install -e '.[textract]'
```

## Python

```python
from omniparse import DocumentParser
result = DocumentParser(mode="auto").parse("document.pdf")
print(result.markdown)
for chunk in result.chunk(max_chars=1500, overlap_chars=150):   # list[Chunk]
    print(chunk.index, chunk.pages, chunk.heading_path, chunk.text[:60])
result.chunks()   # same thing as plain dicts
```

## CLI

```bash
omniparse parse document.pdf --mode fast --format json
omniparse parse document.pdf --format chunks --max-chars 1200 --overlap 120   # JSON Lines, one chunk per line
omniparse parse document.pdf --no-layout --format markdown                   # flat extraction
```

## Layout-aware extraction and chunking

For native PDFs the PyMuPDF backend no longer flattens a page to a string. It reads positioned text
(`get_text("dict")`) and tables (`find_tables()`), and `omniparse.layout` turns that into ordered, typed
blocks (`Page.blocks`) plus Markdown `Page.text`:

- **Reading order**: multi-column pages are read column by column; full-width blocks (titles, wide tables) split the page into bands.
- **Headings**: detected from the font-size ladder (and short bold lines), levels assigned by size rank.
- **Paragraphs, lists, code, captions, tables**: fused text blocks are split into paragraphs, wrapped lines are re-joined (hyphenation repaired), lists/bullets and monospace code are recognised, `Table 1:`/`Figure 2.` captions are tagged, tables become Markdown.
- **Running headers/footers/page numbers** are detected across pages and kept out of the text (still available as `header`/`footer` blocks).

`DocumentParser(layout=False)` / `--no-layout` restores flat extraction. If layout analysis raises, the parser warns and falls back to flat text.

Chunks come from `omniparse.chunking.chunk_pages` (exposed as `ParseResult.chunk()` / `.chunks()`) and work on those blocks:

- Chunks follow reading order and never mix columns or include headers/footers.
- Split on semantic boundaries: block, then sentence, line, word; a hard slice only for a single token longer than `max_chars`. Small blocks are packed together and chunks can span pages. `len(chunk.text) <= max_chars` always holds, overlap included.
- Headings feed a `heading_path` breadcrumb and are never stranded at the end of a chunk; a new chunk starts at `#`/`##` headings (`split_heading_level`) once enough content has accumulated. No overlap crosses a section break.
- Each table gets its own chunk(s) (`isolate_tables=True`) together with its caption (above or below); oversized tables split on row boundaries. Code and lists stay whole when they fit.
- Overlap is whole units from the end of the previous chunk (`overlap_chars` is a budget; default `min(150, max_chars/5)`).
- Pages without layout blocks (MinerU, Textract, hand-built `Page`s) fall back to structure recovered from the Markdown (headings, fences, tables), so the same API works everywhere.
- Linear time: ~5 MB of text chunks in well under a second.

Each `Chunk` carries:

| Group | Fields |
| --- | --- |
| Sequence | `index`, `total_chunks`, `prev_id`, `next_id` |
| Identity | `chunk_id` (deterministic from source + position + text), `text_hash` (text only; for dedupe / skipping re-embedding), `source` |
| Location | `start_char`, `end_char` (offsets into `ParseResult.markdown`; `markdown[start_char:end_char] == text`), `overlap_chars` (`text[:overlap_chars]` repeats the previous chunk), `regions` (per-page bbox `[x0, y0, x1, y1]` of the chunk's own content, for highlighting/citations) |
| Provenance | `page_start`, `page_end`, `pages`, `engines`, `heading_path` (section at the chunk's first new content), `content_types` (`text`/`heading`/`list`/`code`/`table`/`caption`) |
| Size | `char_count`, `token_estimate` (chars/4; use a real tokenizer if you need exact counts) |

Notes: `regions` use the bbox of whole layout blocks, so a chunk cut from the middle of a long paragraph still reports that paragraph's box. The MinerU adapter returns the whole document as one "page 1", so its chunks have correct order, offsets and headings but neither true page numbers nor regions until it emits per-page blocks.

## Implementation status

- Implemented: PyMuPDF PDF extraction, MinerU CLI adapter, single-image Textract OCR, Pydantic schema, CLI, layout-aware PyMuPDF extraction (columns, headings, tables, headers/footers) and layout-aware chunking with sequence/page/heading/region metadata, skill instructions.
- Planned: true per-page hybrid routing, Office adapters, asynchronous Textract PDF jobs, structured MinerU blocks and page provenance, table normalization, token-aware chunking (pluggable tokenizer), retries, concurrency, benchmarks, MCP server and REST API.
- Auto mode uses native PDF extraction and optionally falls back to MinerU when most pages lack text; it is not yet page-level routing.
- MinerU adapter is CLI-based, expects `mineru-kit` installed, and returns one Markdown block; verify exact tier support against installed MinerU version.
- This is a starter scaffold, not a production-ready release or a published PyPI package.
